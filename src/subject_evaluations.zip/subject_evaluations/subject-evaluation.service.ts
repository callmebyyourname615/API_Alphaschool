import { Injectable, NotFoundException } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { SubjectEvaluation } from './subject-evaluation.entity';
import { Lesson } from '../lesson/lesson.entity';
import { CreateSubjectEvaluationDto } from './dto/create-subject-evaluation.dto';
import { UpdateSubjectEvaluationDto } from './dto/update-subject-evaluation.dto';

const RELATIONS = [
  'lesson',
  'lesson.subjectType',
  'lesson.yearLevel',
  'lesson.curriculums',
];

@Injectable()
export class SubjectEvaluationService {
  constructor(
    @InjectRepository(SubjectEvaluation)
    private readonly evalRepo: Repository<SubjectEvaluation>,
    @InjectRepository(Lesson)
    private readonly lessonRepo: Repository<Lesson>,
  ) {}

  // Read all
  async findAll(): Promise<SubjectEvaluation[]> {
    return this.evalRepo.find({
      relations: RELATIONS,
    });
  }

  // Read one
  async findOne(id: string): Promise<SubjectEvaluation> {
    const evalEntity = await this.evalRepo.findOne({
      where: { id },
      relations: RELATIONS,
    });
    if (!evalEntity) throw new NotFoundException(`Evaluation ${id} not found`);
    return evalEntity;
  }

  // Create
  async create(dto: CreateSubjectEvaluationDto): Promise<SubjectEvaluation> {
    const lesson = await this.lessonRepo.findOne({
      where: { id: dto.lesson_id },
    });
    if (!lesson) throw new NotFoundException(`Lesson ${dto.lesson_id} not found`);

    const evalEntity = this.evalRepo.create({
      lessonId: dto.lesson_id,
      lesson,
      topic:       dto.topic,
      description: dto.description,
      contents:    dto.contents,
    });

    const saved = await this.evalRepo.save(evalEntity);
    return this.findOne(saved.id);
  }

  // Update
  async update(id: string, dto: UpdateSubjectEvaluationDto): Promise<SubjectEvaluation> {
    const evalEntity = await this.evalRepo.findOne({
      where: { id },
      relations: ['lesson'],
    });
    if (!evalEntity) throw new NotFoundException(`Evaluation ${id} not found`);

    if (dto.lesson_id && dto.lesson_id !== evalEntity.lessonId) {
      const lesson = await this.lessonRepo.findOne({ where: { id: dto.lesson_id } });
      if (!lesson) throw new NotFoundException(`Lesson ${dto.lesson_id} not found`);
      evalEntity.lesson   = lesson;
      evalEntity.lessonId = dto.lesson_id;
    }

    evalEntity.topic       = dto.topic       ?? evalEntity.topic;
    evalEntity.description = dto.description ?? evalEntity.description;
    evalEntity.contents    = dto.contents    ?? evalEntity.contents;

    await this.evalRepo.save(evalEntity);
    return this.findOne(id);
  }

  // Filter by subject type name
  async findBySubjectName(name: string): Promise<SubjectEvaluation[]> {
    return this.evalRepo
      .createQueryBuilder('se')
      .leftJoinAndSelect('se.lesson', 'lesson')
      .leftJoinAndSelect('lesson.subjectType', 'subjectType')
      .leftJoinAndSelect('lesson.yearLevel', 'yearLevel')
      .leftJoinAndSelect('lesson.curriculums', 'curriculums')
      .where('subjectType.name = :name', { name })
      .getMany();
  }

  // Delete
  async remove(id: string): Promise<void> {
    const result = await this.evalRepo.delete(id);
    if (result.affected === 0) throw new NotFoundException(`Evaluation ${id} not found`);
  }
}